package byd.cxkcxkckx.gotome.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_5498;

public class GotomeClient {
    public static class_304 motionCameraKey;
    public static class_304 freeLookKey;
    public static class_304 openConfigKey;
    public static class_304 viewLockKey;
    public static final CameraController cameraController = new CameraController();
    private static class_5498 lastPerspective = null;
    private static boolean lastWorldLoaded = false;

    public static void init() {
        motionCameraKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.gotome.motion_camera",
                ConfigManager.config.motionCameraKey,
                "category.gotome"
        ));
        freeLookKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.gotome.freelook",
                ConfigManager.config.freeLookKey,
                "category.gotome"
        ));
        openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.gotome.open_config",
                net.minecraft.class_3675.field_16237.method_1444(),
                "category.gotome"
        ));
        viewLockKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.gotome.view_lock",
                ConfigManager.config.viewLockKey,
                "category.gotome"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (motionCameraKey.method_1436()) {
                boolean wasEnabled = ConfigManager.config.motionCameraEnabled;
                ConfigManager.config.motionCameraEnabled = !ConfigManager.config.motionCameraEnabled;
                if (!wasEnabled && ConfigManager.config.motionCameraEnabled && client.field_1724 != null) {
                    client.field_1724.method_36456(client.field_1724.method_36454() + 360f);
                }
            }
            while (freeLookKey.method_1436()) {
                ConfigManager.config.freeLookEnabled = !ConfigManager.config.freeLookEnabled;
            }
            while (openConfigKey.method_1436()) {
                class_310.method_1551().method_1507(ConfigScreen.create(null));
            }
            while (viewLockKey.method_1436()) {
                ConfigManager.config.viewLockEnabled = !ConfigManager.config.viewLockEnabled;
            }

            cameraController.tick(client);

            class_5498 currentPerspective = client.field_1690.method_31044();
            boolean worldLoaded = client.field_1687 != null;
            if (client.field_1724 != null && ConfigManager.config.motionCameraEnabled && !currentPerspective.method_31034()) {
                if ((lastPerspective != null && lastPerspective.method_31034() && !currentPerspective.method_31034()) || (!lastWorldLoaded && worldLoaded)) {
                    client.field_1724.method_36456(client.field_1724.method_36454());
                }
            }
            lastPerspective = currentPerspective;
            lastWorldLoaded = worldLoaded;
        });
    }
}