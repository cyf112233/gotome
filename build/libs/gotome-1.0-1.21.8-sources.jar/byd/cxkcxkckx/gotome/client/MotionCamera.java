package byd.cxkcxkckx.gotome.client;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5498;

public class MotionCamera {
    public class_243 cameraPos;
    private Float lastYaw = null;
    private Float lastPitch = null;
    private Float inertiaYawSpeed = 0f;
    private Float inertiaPitchSpeed = 0f;
    private static final double SLEEP_CAM_LERP = 0.2;
    private static final double SLEEP_CAM_HEIGHT = 2.5;
    private static final float SLEEP_CAM_PITCH = 90f;

    public boolean firstPerson() {
        return class_310.method_1551().field_1690.method_31044() == class_5498.field_26664;
    }

    public class_243 getCameraPos() {
        if (firstPerson()) {
            return new class_243(
                    class_310.method_1551().field_1724.method_23317(),
                    class_310.method_1551().field_1724.method_23318() + class_310.method_1551().field_1724.method_18381(class_310.method_1551().field_1724.method_18376()),
                    class_310.method_1551().field_1724.method_23321()
            );
        }
        return cameraPos;
    }

    public void update(class_243 playerPos, float tickDelta) {
        if (class_310.method_1551().field_1724 == null) return;
        if (class_310.method_1551().field_1724.method_6113()) return;
        if (ConfigManager.config.viewLockEnabled) return;
        if (ConfigManager.config.motionCameraEnabled) {
            if (cameraPos == null) {
                cameraPos = playerPos;
            }
            double distance = cameraPos.method_1022(playerPos);
            double maxDist = ConfigManager.config.motionCameraMaxDistance;
            if (distance > maxDist) {
                cameraPos = new class_243(playerPos.field_1352, playerPos.field_1351 + 1.0, playerPos.field_1350);
            } else {
                double smoothFactor = ConfigManager.config.motionCameraSmoothness;
                double dynamicFactor = smoothFactor * (1.0 - Math.exp(-distance / maxDist));
                double dx = playerPos.field_1352 - cameraPos.field_1352;
                double dy = playerPos.field_1351 + class_310.method_1551().field_1724.method_18381(class_310.method_1551().field_1724.method_18376()) - cameraPos.field_1351;
                double dz = playerPos.field_1350 - cameraPos.field_1350;
                cameraPos = new class_243(
                        cameraPos.field_1352 + dx * dynamicFactor,
                        cameraPos.field_1351 + dy * dynamicFactor,
                        cameraPos.field_1350 + dz * dynamicFactor
                );
            }
            if (ConfigManager.config.motionCameraYawInertiaEnabled) {
                float currentYaw = class_310.method_1551().field_1724.method_36454();
                float currentPitch = class_310.method_1551().field_1724.method_36455();
                if (lastYaw == null) lastYaw = currentYaw;
                if (lastPitch == null) lastPitch = currentPitch;
                float deltaYaw = currentYaw - lastYaw;
                float deltaPitch = currentPitch - lastPitch;
                float inertia = (float) ConfigManager.config.motionCameraYawInertia;
                float speed = (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
                float threshold = 0.01f;
                if (speed > threshold) {
                    inertiaYawSpeed = deltaYaw;
                    inertiaPitchSpeed = deltaPitch;
                } else {
                    inertiaYawSpeed *= (1f - inertia);
                    inertiaPitchSpeed *= (1f - inertia);
                    class_310.method_1551().field_1724.method_36456(currentYaw + inertiaYawSpeed);
                    class_310.method_1551().field_1724.method_36457(currentPitch + inertiaPitchSpeed);
                }
                if (Math.abs(inertiaYawSpeed) < 0.001f) inertiaYawSpeed = 0f;
                if (Math.abs(inertiaPitchSpeed) < 0.001f) inertiaPitchSpeed = 0f;
                lastYaw = class_310.method_1551().field_1724.method_36454();
                lastPitch = class_310.method_1551().field_1724.method_36455();
            } else {
                lastYaw = null;
                lastPitch = null;
                inertiaYawSpeed = 0f;
                inertiaPitchSpeed = 0f;
            }
        }
    }
}