package byd.cxkcxkckx.gotome.client;

import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_5498;

public final class CameraController {
    private class_243 cameraPos;
    private boolean freeLookActive = false;
    private float freeLookYaw;
    private float freeLookPitch;
    private Double lastFollowY;
    private Float lastPlayerYaw;
    private Float lastPlayerPitch;
    private float inertiaYawVelocity;
    private float inertiaPitchVelocity;
    private double verticalFollowOffset;
    private double verticalFollowVelocity;

    public void tick(class_310 client) {
        class_1657 player = client.field_1724;
        if (player == null) {
            resetTransientState();
            return;
        }

        if (ConfigManager.config.viewLockEnabled) {
            freeLookActive = false;
            return;
        }

        updateFreeLookState(client, player);
        updateMovementFollow(client, player);
        updateMouseInertia(player);
    }

    public void applyCameraPosition(class_310 client, class_243 playerPos, float tickDelta, Object[] argsHolder) {
        if (client.field_1724 == null) return;
        if (!ConfigManager.config.motionCameraEnabled) return;
        if (ConfigManager.config.motionCameraDisableFirstPers && firstPerson(client)) return;

        updateCameraPosition(client, playerPos, tickDelta);
        class_243 pos = getCameraPos(client);
        argsHolder[0] = pos.field_1352;
        argsHolder[1] = pos.field_1351;
        argsHolder[2] = pos.field_1350;
    }

    public void applyCameraRotation(Object[] argsHolder) {
        if (freeLookActive) {
            argsHolder[0] = freeLookYaw;
            argsHolder[1] = freeLookPitch;
        }
    }

    public boolean isFreeLookActive() {
        return freeLookActive;
    }

    public class_243 getCameraPos(class_310 client) {
        if (client.field_1724 == null) {
            return cameraPos;
        }
        if (firstPerson(client)) {
            return new class_243(
                    client.field_1724.method_23317(),
                    client.field_1724.method_23318() + client.field_1724.method_18381(client.field_1724.method_18376()),
                    client.field_1724.method_23321()
            );
        }
        return cameraPos;
    }

    private void updateCameraPosition(class_310 client, class_243 playerPos, float tickDelta) {
        if (cameraPos == null) {
            cameraPos = new class_243(playerPos.field_1352, playerPos.field_1351 + 1.0, playerPos.field_1350);
        }

        double distance = cameraPos.method_1022(playerPos);
        double maxDist = Math.max(1.0, ConfigManager.config.motionCameraMaxDistance);
        if (distance > maxDist) {
            cameraPos = new class_243(playerPos.field_1352, playerPos.field_1351 + 1.0, playerPos.field_1350);
            return;
        }

        double smoothFactor = class_3532.method_15350(ConfigManager.config.motionCameraSmoothness, 0.05, 0.98);
        double dynamicFactor = smoothFactor * (1.0 - Math.exp(-distance / maxDist));
        double horizontalFactor = class_3532.method_15350(dynamicFactor, 0.02, 0.9);
        double verticalFactor = class_3532.method_15350(horizontalFactor + 0.12, 0.05, 0.95);

        double targetY = playerPos.field_1351 + client.field_1724.method_18381(client.field_1724.method_18376());
        double dx = playerPos.field_1352 - cameraPos.field_1352;
        double dy = targetY - cameraPos.field_1351;
        double dz = playerPos.field_1350 - cameraPos.field_1350;

        cameraPos = new class_243(
                cameraPos.field_1352 + dx * horizontalFactor,
                cameraPos.field_1351 + dy * verticalFactor,
                cameraPos.field_1350 + dz * horizontalFactor
        );
    }

    private void updateFreeLookState(class_310 client, class_1657 player) {
        if (!ConfigManager.config.freeLookEnabled || !ConfigManager.config.motionCameraEnabled || firstPerson(client)) {
            freeLookActive = false;
            return;
        }

        boolean keyDown = class_3675.method_15987(client.method_22683().method_4490(), ConfigManager.config.freeLookKey);
        if (keyDown && !freeLookActive) {
            freeLookActive = true;
            freeLookYaw = player.method_36454();
            freeLookPitch = player.method_36455();
        } else if (!keyDown && freeLookActive) {
            freeLookActive = false;
        }
    }

    private void updateMovementFollow(class_310 client, class_1657 player) {
        if (!ConfigManager.config.freeLookEnabled || freeLookActive || !ConfigManager.config.motionCameraEnabled || firstPerson(client)) {
            lastFollowY = null;
            verticalFollowOffset = 0.0;
            verticalFollowVelocity = 0.0;
            return;
        }

        double currentY = player.method_23318();
        if (lastFollowY == null) {
            lastFollowY = currentY;
            return;
        }

        double deltaY = currentY - lastFollowY;
        double sensitivity = Math.max(0.1f, ConfigManager.config.freeLookVerticalSensitivity);
        double targetOffset = -deltaY * sensitivity * 2.5;

        verticalFollowVelocity = verticalFollowVelocity * 0.78 + targetOffset * 0.22;
        verticalFollowOffset = verticalFollowOffset * 0.82 + verticalFollowVelocity * 0.18;

        float nextPitch = class_3532.method_15363(player.method_36455() + (float) verticalFollowOffset, -90.0f, 90.0f);
        player.method_36457(nextPitch);
        lastFollowY = currentY;
    }

    private void updateMouseInertia(class_1657 player) {
        if (!ConfigManager.config.motionCameraYawInertiaEnabled || !ConfigManager.config.motionCameraEnabled || firstPerson(class_310.method_1551()) || freeLookActive) {
            lastPlayerYaw = null;
            lastPlayerPitch = null;
            inertiaYawVelocity = 0f;
            inertiaPitchVelocity = 0f;
            return;
        }

        float currentYaw = player.method_36454();
        float currentPitch = player.method_36455();
        if (lastPlayerYaw == null || lastPlayerPitch == null) {
            lastPlayerYaw = currentYaw;
            lastPlayerPitch = currentPitch;
            return;
        }

        float deltaYaw = class_3532.method_15393(currentYaw - lastPlayerYaw);
        float deltaPitch = currentPitch - lastPlayerPitch;
        float response = class_3532.method_15363((float) ConfigManager.config.motionCameraYawInertia, 0.02f, 0.35f);

        // Use a continuous filter instead of a hard stop threshold so mouse motion feels natural.
        inertiaYawVelocity += (deltaYaw - inertiaYawVelocity) * response;
        inertiaPitchVelocity += (deltaPitch - inertiaPitchVelocity) * response;
        inertiaYawVelocity *= 1.0f - response * 0.12f;
        inertiaPitchVelocity *= 1.0f - response * 0.12f;

        float nextYaw = class_3532.method_15393(currentYaw + inertiaYawVelocity);
        float nextPitch = class_3532.method_15363(currentPitch + inertiaPitchVelocity, -90.0f, 90.0f);
        player.method_36456(nextYaw);
        player.method_36457(nextPitch);

        lastPlayerYaw = nextYaw;
        lastPlayerPitch = nextPitch;
    }

    private boolean firstPerson(class_310 client) {
        return client.field_1690.method_31044() == class_5498.field_26664;
    }

    private void resetTransientState() {
        freeLookActive = false;
        lastFollowY = null;
        lastPlayerYaw = null;
        lastPlayerPitch = null;
        inertiaYawVelocity = 0f;
        inertiaPitchVelocity = 0f;
        verticalFollowOffset = 0.0;
        verticalFollowVelocity = 0.0;
    }
}
