package byd.cxkcxkckx.gotome.mixin;

import byd.cxkcxkckx.gotome.client.ConfigManager;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, float tickDelta, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null && ConfigManager.config.motionCameraEnabled && client.field_1724.method_6113()) {
            int width = client.method_22683().method_4486();
            int height = client.method_22683().method_4502();
            context.method_25294(0, 0, width, height, 0xFF000000);
        }
    }
} 