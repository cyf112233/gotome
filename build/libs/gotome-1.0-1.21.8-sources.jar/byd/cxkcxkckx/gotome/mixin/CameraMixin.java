package byd.cxkcxkckx.gotome.mixin;

import byd.cxkcxkckx.gotome.client.GotomeClient;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow private boolean thirdPerson;
    @Shadow private class_243 pos;
    @Shadow private float yaw;
    @Shadow private float pitch;

    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Unique
    private float tickDelta;

    @Inject(method = "update", at = @At("HEAD"))
    private void onUpdateHead(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo info) {
        this.tickDelta = tickDelta;
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"))
    private void onSetCameraPosition(Args args) {
        if (class_310.method_1551().field_1724 == null) return;
        Object[] coords = new Object[] { args.get(0), args.get(1), args.get(2) };
        GotomeClient.cameraController.applyCameraPosition(class_310.method_1551(), class_310.method_1551().field_1724.method_19538(), tickDelta, coords);
        args.set(0, (Double) coords[0]);
        args.set(1, (Double) coords[1]);
        args.set(2, (Double) coords[2]);
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void onUpdateSetRotationArgs(Args args) {
        Object[] rot = new Object[] { args.get(0), args.get(1) };
        GotomeClient.cameraController.applyCameraRotation(rot);
        args.set(0, (Float) rot[0]);
        args.set(1, (Float) rot[1]);
    }
}